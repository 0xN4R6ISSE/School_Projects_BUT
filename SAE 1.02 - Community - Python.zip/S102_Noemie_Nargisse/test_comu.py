from comu import *


def test_cree_reseau():
    """
    Effectue des tests unitaires sur la fonction cree_reseau, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    t1 = ["Alice", "Bob", "Bob", "Carl", "Alice", "Dan", "Bob", "Dan"]
    assert cree_reseau(t1) == amis

    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    t2 = ["Maria", "Dominique", "Emma", "Justin", "Justin", "Damien"]
    assert cree_reseau(t2) == amis2

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    t3 = ["David", "Maya", "David", "Bryan", "Ellie", "Bryan"]
    assert cree_reseau(t3) == amis3

    print("Test de la fonction cree_reseau : OK")


def test_liste_personnes():
    """
    Effectue des tests unitaires sur la fonction liste_personnes, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    assert liste_personnes(amis) == ["Alice", "Bob", "Carl", "Dan"]

    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    assert liste_personnes(amis2) == ["Maria", "Dominique", "Emma", "Justin", "Damien"]

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    assert liste_personnes(amis3) == ["David", "Maya", "Bryan", "Ellie"]

    print("Test de la fonction liste_personnes : OK")


def test_sont_amis():
    """
    Effectue des tests unitaires sur la fonction sont_amis, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    assert sont_amis("Alice", "Dan", amis)
    assert sont_amis("Dan", "Bob", amis)
    assert not(sont_amis("Carl", "Dan", amis))

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    assert sont_amis("Bryan", "David", amis3)
    assert not(sont_amis("Ellie", "Maya", amis3))

    print("Test de la fonction sont_amis : OK")


def test_sont_amis_de():
    """
    Effectue des tests unitaires sur la fonction sont_amis_de, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    assert sont_amis_de("Bob", ["Carl", "Dan"], amis)
    assert not(sont_amis_de("Carl", ["Bob", "Alice", "Dan"], amis))

    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    assert not(sont_amis_de("Justin", ["Dominique", "Emma"], amis2))
    assert not(sont_amis_de("Maria", ["Emma", "Justin", "Damien"], amis2))

    print("Test de la fonction sont_amis_de : OK")


def test_est_comu():
    """
    Effectue des tests unitaires sur la fonction est_comu, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    assert est_comu(["Carl", "Bob"], amis)
    assert est_comu(["Dan", "Alice", "Bob"], amis)
    assert not(est_comu(["Dan", "Carl", "Bob"], amis))

    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    assert not(est_comu(["Justin", "Damien", "Emma"], amis2))
    assert est_comu(["Dominique", "Maria"], amis2)
    assert not(est_comu(["Emma", "Dominique", "Justin"], amis2))

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    assert est_comu(["David, Maya"], amis3)
    assert not(est_comu(["Bryan", "David", "Maya", "Ellie"], amis3))

    print("Test de la fonction est_comu : OK")


def test_comu():
    """
    Effectue des tests unitaires sur la fonction test_comu, et affiche si tous les tests se sont bien déroulés.
    """
    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    assert comu(["Maria", "Dominique", "Justin", "Emma"], amis2) == ["Maria", "Dominique"]
    assert comu(["Emma", "Dominique", "Justin", "Damien"], amis2) == ["Emma", "Justin"]

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    assert comu(["David", "Ellie", "Bryan"], amis3) == ["David", "Bryan"]
    assert comu(["Ellie", "David", "Maya"], amis3)

    print("Test de la fonction test_comu : OK")


def test_tri_popu():
    """
    Effectue des tests unitaires sur la fonction tri_popu, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    t1 = ["Alice", "Carl", "Bob", "Dan"]
    tri_popu(t1, amis)
    assert t1 == ["Bob", "Alice", "Dan", "Carl"]

    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    t2 = ["Maria", "Justin", "Emma"]
    tri_popu(t2, amis2)
    assert t2 == ["Justin", "Maria", "Emma"]

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    t3 = ["Maya", "Bryan", "Ellie", "David"]
    tri_popu(t3, amis3)
    assert t3 == ["Bryan", "David", "Maya", "Ellie"]

    print("Test de la fonction tri_popu : OK")

def test_comu_dans_reseau():
    """
    Effectue des tests unitaires sur la fonction comu_dans_reseau, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    assert comu_dans_reseau(amis) == ["Bob", "Alice", "Dan"]

    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    assert comu_dans_reseau(amis2) == ["Justin", "Emma"]

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    assert comu_dans_reseau(amis3) == ["David", "Bryan"]

    print("Test de la fonction comu_dans_reseau : OK")

def test_comu_dans_amis():
    """
    Effectue des tests unitaires sur la fonction comu_dans_amis, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    assert comu_dans_amis("Bob", amis) == ["Bob", "Alice", "Dan"]
    assert comu_dans_amis("Carl", amis) == ["Carl", "Bob"]

    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    assert comu_dans_amis("Justin", amis2) == ["Justin", "Emma"]
    assert comu_dans_amis("Maria", amis2) == ["Maria", "Dominique"]

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    assert comu_dans_amis("David", amis3) == ["David", "Bryan"]
    assert comu_dans_amis("Bryan", amis3) == ["Bryan", "David"]

    print("Test de la fonction comu_dans_amis : OK")

def test_comu_max():
    """
    Effectue des tests unitaires sur la fonction comu_max, et affiche si tous les tests se sont bien déroulés.
    """
    amis = { "Alice" : ["Bob", "Dan"], "Bob": ["Alice", "Carl", "Dan"], "Carl": ["Bob"], "Dan": ["Alice", "Bob"]}
    assert comu_max(amis) == ["Alice", "Bob", "Dan"]

    amis2 = {'Maria': ['Dominique'], 'Dominique': ['Maria'], 'Emma': ['Justin'], 'Justin': ['Emma', 'Damien'], 'Damien': ['Justin']}
    assert comu_max(amis2) == ["Maria", "Dominique"]

    amis3 = {'David': ['Maya', 'Bryan'], 'Maya': ['David'], 'Bryan': ['David', 'Ellie'], 'Ellie': ['Bryan']}
    assert comu_max(amis3) == ["David", "Bryan"]

    print("Test de la fonction comu_max : OK")



