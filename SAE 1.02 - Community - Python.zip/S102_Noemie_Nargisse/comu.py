#fonctions de la SAÉ 1
def personnes(amis):
    """
    Retourne le tableau des différentes personnes contenu dans le tableau 'amis'.
    """
    personnes=[]
    i=0
    while i<len(amis):
        if amis[i] not in personnes:
            personnes.append(amis[i])
        i+=1
    return personnes



def ses_amis(amis, prenom):
    """
    Retourne le tableau des amis de prenom.
    """
    ses_amis=[]
    i=0
    while i<len(amis)/2:
        if amis[2*i]== prenom :
            ses_amis.append(amis[2*i+1])
        elif amis[2*i+1]==prenom :
            ses_amis.append(amis[2*i])
        i+=1
    return ses_amis


#version non optimisée 
def dico_reseau(amis):
    """
    Retourne le dictionnaire qui contient la modélisation des intéractions dans un réseau d'amis.
    """
    reseau={}
    pers=personnes(amis)
    i=0
    while i<len(pers):
        reseau[pers[i]]=ses_amis(amis,pers[i])
        i+=1
    return reseau

#question 1
def cree_reseau(tab):
    """
    Retourne le dictionnaire qui représente un réseau d'amis.
        Parameters:
            tab(list): tableau contenant les intéractions du réseau d'amitié sous forme de paires.
        Return:
            d(dict): dictionnaire représentant le réseau.
            Les clés sont les prénoms des membres et les valeurs sont les tableaux contenant les prénoms de leurs amis.
    """
    #initialisation du dictionnaire du reseau
    d = {}
    #parcours du tableau tab
    i = 0
    while 2*i < len(tab):
        #initialisation de la variable 'a' qui correspond à la première personne du couple d'amis
        a = tab[2*i]
        #intilisation de la variable 'b' qui correspond à la seconde personne du couple d'amis
        b = tab[2*i+1]
        #si 'a' n'est pas dans le dictionnaire, on le rajoute et lui attribue un tableau contenant son ami 'b'
        if a not in d:
            d[a] = [b]
        #sinon, on ajoute simplement 'b' au tableau de 'a'
        else:
            d[a].append(b) 
        #on répète le meme processus avec 'b'
        if b not in d:
            d[b] = [a]
        else:
            d[b].append(a)
        i += 1
    return d

#question 3
def liste_personnes(reseau):
    """
    Retourne la liste des membres du réseau.
        Parameters:
            reseau(dict): dictionnaire représentant le réseau.
            Les clés sont les prénoms des membres et les valeurs sont les tableaux contenant les prénoms de leurs amis.
        Return:
            list(reseau): un tableau contenant les valeurs du dictionnaire 'reseau'.
    """
    return list(reseau) 

#question 4
def sont_amis(p1, p2, reseau):
    """
    Vérifie si deux personnes sont amis ou non.
        Parameters:
            reseau(dict): dictionnaire représentant le réseau.
                          Les clés sont les prénoms des membres et les valeurs sont les tableaux contenant les prénoms de leurs amis.
            p1 et p2(str): prénoms des deux personnes concernées.
        Return:
            bool: True si p1 et p2 sont amis, False sinon.
    """
    #si p1 n'est pas dans la liste des amis de p2, on retourne False
    if p1 not in reseau[p2]:
        return False
    return True

#question 5
def sont_amis_de(personne, groupe, reseau):
    """
    Vérifie que tous les membres d'un groupe sont amis ou non avec une personne spécifique.
        Parameters:
            reseau(dict): dictionnaire représentant le réseau.
            Les clés sont les prénoms des membres et les valeurs sont les tableaux contenant les prénoms de leurs amis.
            groupe(list): tableau contenant les prénoms des membres du groupe.
            personne(str): prénom de la personne avec laquelle on vérifie l'amitié.
        Return:
            bool: True si tous les membres du groupe sont amis avec la personne, False sinon.
    """
    #parcours du tableau groupe
    i = 0
    while i < len(groupe):
        #si 'personne' et le membre du groupe ne sont pas amis, on return False
        if not(sont_amis(personne, groupe[i], reseau)):
               return False
        i += 1
    return True

#question 6
def est_comu(groupe, reseau):
    """
    Return True si le groupe passé en paramètres est bien une communauté dans le réseau, c'est-à-dire que tous les membres sont amis entre eux.
        Parameters:
            groupe(list): tableau contenant les prénoms des membres du groupe.
            reseau(dict): dictionnaire représentant le réseau.
            Les clés sont les prénoms des membres, et les valeurs sont les tableaux contenant les prénoms de leurs amis.
        Return:
            bool: True si tous les membres du groupe sont amis entre eux, False sinon.
    """
    #parcours du tableau groupe
    i = 0
    while i < len(groupe):
        #on récupére le prénom du membre actuel
        prenom = groupe[i]
        #deuxieme parcours du tableau groupe
        j = 0
        while j < len(groupe):
            #on vérifie que prenom est ami avec tous les membres du groupe en faisant attention à ne pas le comparer avec lui-meme
            #s'il n'est pas ami avec un des membres du groupe, on return False
            if groupe[j] != prenom and not(sont_amis(prenom, groupe[j], reseau)):
                return False
            j += 1
        i +=1
    return True

#question 7
def comu(groupe, reseau):
    """
    Renvoie la communauté maximale que l'on peut former à partir d'un groupe de personnes.
        Parameters:
            groupe(list): tableau contenant les prénoms des membres du groupe.
            reseau(dict): dictionnaire représentant le réseau.
            Les clés sont les prénoms des membres, et les valeurs sont les tableaux contenant les prénoms de leurs amis.
        Return:
            c(list): tableau qui représente la communauté que l'on a cherché à construire.
    """
    #initialisation de la variable qui va contenir le tableau des membres de la communauté
    c = []
    #parcours du tableau groupe
    i = 0
    while i < len(groupe):
        #initialisation de la variable 'prenom' qui contient le prenom d'un membre du groupe
        prenom = groupe[i]
        #si la personne est amie avec tous les membres de la communauté, on l'ajoute à la communauté
        if sont_amis_de(prenom, c, reseau):
            c.append(prenom)
        i += 1
    return c

#question8
def tri_popu(groupe, reseau):
    """
    Trie un groupe en fonction de la popularité (nombre d'amis) de façon décroissante en utilisant l'agorithme du tri à bulles (bubble sort).
        Parameters:
            groupe(list): tableau contenant les prénoms des membres du groupe.
            reseau(dict): dictionnaire représentant le réseau.
                        Les clés sont les prénoms des membres, et les valeurs sont les tableaux contenant les prénoms de leurs amis.
    """
    #parcours du tableau groupe jusqu'à ce que tous les éléments soient triés
    i = 0
    while i < len(groupe)-1:
        #parcours du tableau groupe jusqu'aux éléments triés
        j = 0
        while j < len(groupe)-1-i:
            #si le premier membre à moins d'amis que son voisin, on les échange
            if len(reseau[groupe[j]]) < len(reseau[groupe[j+1]]):
                groupe[j], groupe[j+1] = groupe[j+1], groupe[j]
            j += 1
        i += 1

#question9
def comu_dans_reseau(reseau):
    """
    Retourne la communauté maximale construite après avoir trié les membres d'un réseau par popularité décroissante.
        Parameters:
            reseau(dict): dictionnaire représentant le réseau.
                          Les clés sont les prénoms des membres, et les valeurs sont les tableaux contenant les prénoms de leurs amis.
        Return:
            c(list): tableau qui représente la communauté que l'on a construite.
    """
    #initialisation d'un tableau groupe qui contient la liste des membres du reseau
    groupe = liste_personnes(reseau)
    #triage du tableau de façcon décroissante par rapport à la taille de la liste d'amis de chaque membre du groupe
    tri_popu(groupe, reseau)
    #Renvoie de la communauté crée à partir du groupe trié
    return comu(groupe, reseau)

#question10
def comu_dans_amis(prenom, reseau):
    """
    Retourne la communauté maximale construite à partir d'un individu et de sa liste d'amis après l'avoir trié par ordre décroissante de popularité.
        Parameters:
            prenom(str): prénom de la personne (au sein du réseau) dont on cherche à constuire une communauté à partir de sa liste d'amis.
            reseau(dict): dictionnaire représentant le réseau.
                          Les clés sont les prénoms des membres, et les valeurs sont les tableaux contenant les prénoms de leurs amis.
        Return:
            c(list): tableau qui représente la communauté que l'on a construite.
    """
    #initialisation du tableau c de la communauté
    c = []
    #on ajoute le prenom précisé en paramètres
    c.append(prenom)
    #initialisation de la variable amis contenant la liste des amis de 'prenom'
    amis = reseau[prenom]
    #triage du tableau 'amis' selon la popularité décroissante de chaque membre du groupe
    tri_popu(amis, reseau)
    #parcours du tableau 'amis' 
    i = 0
    while i < len(amis):
        #initialisation de 'prenom2' avec un membre du groupe d'amis de 'prenom'
        prenom2 = amis[i]
        #si 'prenom2' est bien ami avec tous les membres de la communauté (et vice versa), on le rajoute à 'c'
        if sont_amis_de(prenom2, c, reseau):
            c.append(prenom2)
        i += 1
    return c

#question 12
def comu_max(reseau):
    """
    Retourne la plus grande communauté du réseau obtenue
        Parameters:
            reseau(dict): dictionnaire représentant le réseau.
                          Les clés sont les prénoms des membres, et les valeurs sont les tableaux contenant les prénoms de leurs amis.
        Return:
            maxi(list): la plus grande communauté trouvée.
    """
    #initialisation d'un tableau pour stocker les communautés maximales créées à partir de chaque membre
    tab = []
    #initialisation du tableau personne contenant la liste des personnes du réseau
    prenoms = liste_personnes(reseau)
    #parcours du tableau prenoms
    i = 0
    while i < len(prenoms):
        #initialise p avec un membre du reseau
        p = prenoms[i]
        #ajoute la communauté maximale crée à partir de p à 'tab'
        tab.append(comu_dans_amis(p, reseau))
        i += 1
    #initialisation de la communauté maximale avec la première communauté trouvée
    maxi = tab[0]
    #parcours les communautés restantes pour trouver la plus grande
    j = 1
    while j < len(tab):
        if len(tab[j]) > len(maxi):
            #met à jour 'maxi' si une communauté plus grande est trouvée
            maxi = tab[j]
        j += 1
    return maxi